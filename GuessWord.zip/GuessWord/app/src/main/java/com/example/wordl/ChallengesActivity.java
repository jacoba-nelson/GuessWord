package com.example.wordl;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class ChallengesActivity extends AppCompatActivity {

    private ArrayList<ChallengeSquare> squares = new ArrayList<>();
    private ChallengeSquareAdapter challengeSquareAdapter;
    private GridView gridView;
    private int red = 0, green = 0, blue = 0;
    private int color;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_challenges);
        String challengesFilePath = getApplicationContext().getFilesDir() + "/" + "challenges.txt";
        ChallengesManager challengesManager = new ChallengesManager(challengesFilePath);
        ArrayList<Challenge> challenges = challengesManager.getCurrentChallenges();

        //create a square for every challenge
        for(int i = 0; i < challenges.size(); i++) {
            Challenge challenge = challenges.get(i);
            squares.add(new ChallengeSquare(challenge.toString()));
        }

        //set up the adapter and the gridview
        gridView = findViewById(R.id.challengesgrid);
        challengeSquareAdapter = new ChallengeSquareAdapter(this, R.layout.challenge_square, squares);
        gridView.setAdapter(challengeSquareAdapter);
    }
}