package com.example.wordl;

import android.widget.Toast;

import java.io.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

//this class manages the daily challenges. It reads from a text file, challenges.txt
//and checks to see if the date matches today's date. If it does, it creates the daily
//challenges from the remaining contents of the file. If not, it creates 6 new challenges,
//and writes them to the file.
public class ChallengesManager {
    private ArrayList<Challenge> currentChallenges;
    private String challengesFilePath;

    public ChallengesManager(String filePath) {
        currentChallenges = new ArrayList<>();
        Calendar today = Calendar.getInstance();
        challengesFilePath = filePath;
        File challengesFile = new File(challengesFilePath);
        try {
            // check if file exists, create it if not
            if (!challengesFile.exists()) {
                challengesFile.createNewFile();
            }
            Scanner scanner = new Scanner(challengesFile);
            //check if the file is empty
            if (scanner.hasNextLine()) {
                Calendar savedDate = Calendar.getInstance();
                savedDate.setTimeInMillis(Long.parseLong(scanner.nextLine()));
                //if the date matches, get the challenges from the text file
                if (savedDate.get(Calendar.YEAR) == today.get(Calendar.YEAR)
                        && savedDate.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)) {
                    for (int i = 0; i < 6 && scanner.hasNextLine(); i++) {
                        String challengeText = scanner.nextLine();
                        Challenge challenge = new Challenge(challengeText);
                        String nextLine = scanner.hasNextLine() ? scanner.nextLine() : "";
                        try {
                            int progress = Integer.parseInt(nextLine.trim());
                            challenge.setProgress(progress);
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                        }
                        currentChallenges.add(challenge);
                    }
                    scanner.close();
                    return;
                }
            }
            //if file is empty or date doesn't match, write the date and new challenges to the text file
            scanner.close();
            PrintWriter writer = new PrintWriter(challengesFile);
            writer.println(today.getTimeInMillis());
            for (int i = 0; i < 6; i++) {
                Challenge challenge = new Challenge((int) (Math.random() * 3));
                // write 0 for progress for challenges that are new
                writer.println(challenge.toString());
                writer.println(0);
                currentChallenges.add(challenge);
            }
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Challenge> getCurrentChallenges() {
        return currentChallenges;
    }

    //inspect the challenges and see if they are complete by progress check
    public void inspectChallenges(String word, int time, boolean streakContinues) {
        for(int i = 0; i < currentChallenges.size(); i++) {
            Challenge challenge = currentChallenges.get(i);

            if(challenge.isLetterChallenge()) {
                if(checkLetterAgainstChallenge(word, challenge)) {
                    currentChallenges.get(i).setChallengeComplete(true);
                    currentChallenges.get(i).setProgress(1);
                }
            }
            else if(challenge.isTimedChallenge()) {
                if(time != 0) { //time will be 0 if it was not a timed game
                    if(checkTimeAgainstChallenge(time, challenge)) {
                        currentChallenges.get(i).setChallengeComplete(true);
                        currentChallenges.get(i).setProgress(1);
                    }
                }
            }
            else if(challenge.isStreakChallenge()) {
                if(streakContinues) {
                    currentChallenges.get(i).incrementProgress();
                }
                else {
                    currentChallenges.get(i).setProgress(0);
                }
            }
        }
        saveChallenges();
    }

    public boolean checkLetterAgainstChallenge(String word, Challenge challenge) {
        return word.indexOf(challenge.getLetter()) != -1;
    }

    public boolean checkTimeAgainstChallenge(int time, Challenge challenge) {
        return time <= challenge.getTime();
    }

    public void resetStreakChallenges() {
        for(int i = 0; i < currentChallenges.size(); i++) {
            if(currentChallenges.get(i).isStreakChallenge() && !currentChallenges.get(i).isComplete()) {
                currentChallenges.get(i).setProgress(0);
            }
        }
        saveChallenges();
    }

    //save the challenges to a file: used when a challenge progress is updated
    public void saveChallenges() {
        Calendar today = Calendar.getInstance();
        File challengesFile = new File(challengesFilePath);
        try {
            challengesFile.createNewFile();
            PrintWriter writer = new PrintWriter(challengesFile);
            writer.println(today.getTimeInMillis());
            for (int i = 0; i < currentChallenges.size(); i++) {
                Challenge challenge = currentChallenges.get(i);
                writer.println(challenge.toString());
                writer.println(challenge.getProgress());
            }
            writer.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
