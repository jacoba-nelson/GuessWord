package com.example.wordl;

public class ChallengeSquare {
    private String text;

    ChallengeSquare(String t) {
        this.text = t;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
