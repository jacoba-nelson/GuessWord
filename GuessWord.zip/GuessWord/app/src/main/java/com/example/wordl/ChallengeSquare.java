package com.example.wordl;

public class ChallengeSquare {
    private String text;
    private int numToComplete;
    private int progress;

    ChallengeSquare(String t, int n, int p) {
        this.text = t;
        this.numToComplete = n;
        this.progress = p;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getNumToComplete() {
        return this.numToComplete;
    }

    public int getProgress() {
        return progress;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }

    public void setNumToComplete(int numToComplete) {
        this.numToComplete = numToComplete;
    }
}
