package com.example.wordl;

import android.graphics.Color;
import android.view.View;

//This is the class for the ColorSquare UI items that populate the
//GridView in the ColorsActivity.
public class ColorSquare {
    private int color;

    ColorSquare(int color) {
        this.color = color;
    }
    public int getColor() {
        return color;
    }
    public void setColor(int color) {
        this.color = color;
    }
}
