package com.example.wordl;

import android.graphics.Color;
import android.view.View;


public class ColorSquare {
    private int color;

    ColorSquare(int color) {
        this.color = color;
    }
    public int getColor() {
        return color;
    }
    public void setColor(int color) {
        this.color = color;
    }
}
