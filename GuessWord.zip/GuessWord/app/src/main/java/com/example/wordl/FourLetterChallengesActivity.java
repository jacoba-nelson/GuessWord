package com.example.wordl;

import android.os.Build;
import android.os.Bundle;
import android.widget.GridView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

//Code for the Challenges Activity for Four-Letter games. Four, Five, Six-
//Letter games are all assigned different Challenges from each other.
public class FourLetterChallengesActivity extends AppCompatActivity {

    private ArrayList<ChallengeSquare> squares = new ArrayList<>();
    private ChallengeSquareAdapter challengeSquareAdapter;
    private GridView gridView;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_four_letter_challenges);

        //read the challenges from the file
        String challengesFilePath = getApplicationContext().getFilesDir() + "/" + "fourletterchallenges.txt";
        ChallengesManager challengesManager = new ChallengesManager(challengesFilePath);
        ArrayList<Challenge> challenges = challengesManager.getCurrentChallenges();

        //create a square for every challenge
        for(int i = 0; i < challenges.size(); i++) {
            Challenge challenge = challenges.get(i);
            squares.add(new ChallengeSquare(challenge.toString(), challenge.getNumToComplete(), challenge.getProgress()));
        }

        //set up the adapter and the gridview
        gridView = findViewById(R.id.challengesgrid);
        challengeSquareAdapter = new ChallengeSquareAdapter(this, R.layout.challenge_square, squares);
        gridView.setAdapter(challengeSquareAdapter);
    }
}