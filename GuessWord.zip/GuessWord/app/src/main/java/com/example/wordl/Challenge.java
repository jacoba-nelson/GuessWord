//This class represents the Challenges for GuessWord. Challenges can be one of the following:
//Timed, Letter, or Streak. Timed Challenges require a word to be completed within a time frame.
//The time frame is between 10 and 60 seconds. Streak Challenges require you to complete a
//designated number of games without losing. Letter Challenges require you to complete a game
//with a word that contains the target letter.

package com.example.wordl;

import java.util.Random;

public class Challenge {
    public static final int TIMED_CHALLENGE = 0;
    public static final int LETTER_CHALLENGE = 1;
    public static final int STREAK_CHALLENGE = 2;
    private int type;
    private String challengeText;
    private int time;
    private char letter;
    private int numToComplete;
    private int progress;
    private boolean challengeComplete;

    //this constructor determines the type of the challenge given an int value.
    //this is used when the daily challenges are created.
    public Challenge(int type) {
        this.type = type;
        Random rand = new Random();

        // generate random time between 10 and 60 seconds
        this.time = rand.nextInt(51) + 10;

        //generate random lowercase letter
        this.letter = (char) (rand.nextInt(26) + 'a');

        //set data according to type
        switch (type) {
            case TIMED_CHALLENGE:
                //for timed challenges, complete 1 to win challenge
                this.numToComplete = 1;
                this.challengeText = "Guess a word in under " + time + " seconds";
                break;
            case LETTER_CHALLENGE:
                //for timed challenges, complete 1 to win challenge
                this.numToComplete = 1;
                this.challengeText = "Get a word with the letter " + letter + " in it";
                break;
            case STREAK_CHALLENGE:
                //generate random streak length between 5 and 15
                this.numToComplete = rand.nextInt(11) + 5;
                this.challengeText = "Get a streak of " + numToComplete + " wins in a row";
                break;
            default:
                throw new IllegalArgumentException("Invalid challenge type: " + type);
        }
    }

    //this constructor takes a string and determines which type of challenge it is and
    //sets the variable (time, streak, letter) appropriately. This is used when the challenges
    //are read from a file.
    public Challenge(String challengeText) {
        this.challengeText = challengeText;
        if (challengeText.startsWith("Guess a word in under ")) {
            this.type = TIMED_CHALLENGE;
            int startIndex = 22;
            int endIndex = challengeText.indexOf(" seconds", startIndex);
            if (endIndex == -1) {
                endIndex = challengeText.length();
            }
            this.time = Integer.parseInt(challengeText.substring(startIndex, endIndex));
            this.numToComplete = 1;
        } else if (challengeText.startsWith("Get a word with the letter ")) {
            this.type = LETTER_CHALLENGE;
            this.letter = challengeText.charAt(challengeText.indexOf(" ", 25) + 1);
            this.numToComplete = 1;
        } else if (challengeText.startsWith("Get a streak of ")) {
            this.type = STREAK_CHALLENGE;
            this.numToComplete = Integer.parseInt(challengeText.substring(16, challengeText.indexOf(" wins")));
        } else {
            throw new IllegalArgumentException("Invalid challenge text: " + challengeText);
        }
    }

    public boolean isStreakChallenge() {
        return this.type == STREAK_CHALLENGE;
    }

    public boolean isLetterChallenge() {
        return this.type == LETTER_CHALLENGE;
    }

    public boolean isTimedChallenge() {
        return this.type == TIMED_CHALLENGE;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }

    public void incrementProgress() {
        this.progress += 1;
        if(progress >= numToComplete) {
            this.challengeComplete = true;
        }
    }

    public int getNumToComplete() {
        return this.numToComplete;
    }

    public int getProgress() {
        return this.progress;
    }

    public void setChallengeComplete(boolean isComplete) {
        this.challengeComplete = isComplete;
    }

    public char getLetter() {
        return this.letter;
    }

    public int getTime() {
        return this.time;
    }

    public boolean isComplete() {
        if(progress >= numToComplete || this.challengeComplete) {
            this.challengeComplete = true;
            return true;
        }
        else return false;
    }

    @Override
    public String toString() {
        return this.challengeText;
    }
}
