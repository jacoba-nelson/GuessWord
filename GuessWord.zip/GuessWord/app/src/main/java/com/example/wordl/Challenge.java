package com.example.wordl;

import java.util.Random;

public class Challenge {
    public static final int TIMED_CHALLENGE = 0;
    public static final int LETTER_CHALLENGE = 1;
    public static final int STREAK_CHALLENGE = 2;
    private int type;
    private String challengeText;
    private int time;
    private char letter;
    private int streak;
    private int streakProgress;
    private boolean challengeComplete;

    //this constructor determines the type of the challenge given an int value.
    //this is used when the daily challenges are created.
    public Challenge(int type) {
        this.type = type;
        Random rand = new Random();

        //generate random time between 30 and 500 seconds
        this.time = rand.nextInt(471) + 30;

        //generate random lowercase letter
        this.letter = (char) (rand.nextInt(26) + 'a');

        //generate random streak length between 5 and 15
        this.streak = rand.nextInt(11) + 5;

        //set data according to type
        switch (type) {
            case TIMED_CHALLENGE:
                this.challengeText = "Guess a word in under " + time + " seconds";
                break;
            case LETTER_CHALLENGE:
                this.challengeText = "Get a word with the letter " + letter + " in it";
                break;
            case STREAK_CHALLENGE:
                this.challengeText = "Get a streak of " + streak + " wins in a row";
                break;
            default:
                throw new IllegalArgumentException("Invalid challenge type: " + type);
        }
    }

    //this constructor takes a string and determines which type of challenge it is and
    //sets the variable (time, streak, letter) appropriately. This is used when the challenges
    //are read from a file.
    public Challenge(String challengeText) {
        this.challengeText = challengeText;
        if (challengeText.startsWith("Guess a word in under ")) {
            this.type = TIMED_CHALLENGE;
            this.time = Integer.parseInt(challengeText.substring(23, challengeText.indexOf(" seconds")));
        } else if (challengeText.startsWith("Get a word with the letter ")) {
            this.type = LETTER_CHALLENGE;
            this.letter = challengeText.charAt(25);
        } else if (challengeText.startsWith("Get a streak of ")) {
            this.type = STREAK_CHALLENGE;
            this.streak = Integer.parseInt(challengeText.substring(16, challengeText.indexOf(" wins")));
        } else {
            throw new IllegalArgumentException("Invalid challenge text: " + challengeText);
        }
    }

    @Override
    public String toString() {
        return this.challengeText;
    }

    public boolean isStreakChallenge() {
        return this.type == STREAK_CHALLENGE;
    }

    public boolean isLetterChallenge() {
        return this.type == LETTER_CHALLENGE;
    }

    public boolean isTimedChallenge() {
        return this.type == TIMED_CHALLENGE;
    }

    public void setStreakProgress(int progress) {
        this.streakProgress = progress;
    }

    public void incrementStreakProgress() {
        this.streakProgress += 1;
        if(streakProgress >= streak) {
            this.challengeComplete = true;
        }
    }

    public int getStreak() {
        return this.streak;
    }

    public int getStreakProgress() {
        return this.streakProgress;
    }

    public void setChallengeComplete(boolean isComplete) {
        this.challengeComplete = isComplete;
    }

    public char getLetter() {
        return this.letter;
    }

    public int getTime() {
        return this.time;
    }
}
