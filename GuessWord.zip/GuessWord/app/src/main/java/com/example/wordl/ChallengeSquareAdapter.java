package com.example.wordl;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;
import java.util.List;

public class ChallengeSquareAdapter extends ArrayAdapter<ChallengeSquare> {

    List<ChallengeSquare> squares = new ArrayList<>();
    int custom_layout_id;

    public ChallengeSquareAdapter(@NonNull Context context, int resource, @NonNull List<ChallengeSquare> objects) {
        super(context, resource, objects);
        squares = objects;
        custom_layout_id = resource;
    }

    @Override
    public int getCount() {
        return squares.size();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
    {
        View v = convertView;
        if (v == null) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(custom_layout_id, null);
        }

        ChallengeSquare square = squares.get(position);
        TextView challengeTextView = v.findViewById((R.id.challengetextview));
        challengeTextView.setText(square.getText());

        String progressText = square.getProgress() + "/" + square.getNumToComplete();
        TextView progressTextView = v.findViewById((R.id.progresstextview));
        progressTextView.setText(progressText);

        return v;
    }
}
