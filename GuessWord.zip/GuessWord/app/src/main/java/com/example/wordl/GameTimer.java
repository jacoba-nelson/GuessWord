package com.example.wordl;

import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class GameTimer {
    private Timer timer;
    private int seconds;

    public GameTimer() {
        seconds = 0;
        timer = new Timer();
    }

    public void start() {
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                seconds++;
            }
        }, 0, 1000);
    }

    public void stop() {
        timer.cancel();
    }

    public void reset() {
        this.seconds = 0;
    }

    public String getTime() {
        int hours = seconds / 3600;
        int minutes = (seconds % 3600) / 60;
        int secs = seconds % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, secs);
    }

    public int getSeconds() {
        return this.seconds;
    }
}
